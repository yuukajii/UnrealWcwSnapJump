// Copyright (c) 2026 WinterCrownWORKS. All Rights Reserved.
// Licensed under the MIT License.

#include "WcwSnapJumpCityTestModule.h"

DEFINE_LOG_CATEGORY(LogWcwCityTest);

#define LOCTEXT_NAMESPACE "FWcwSnapJumpCityTestModule"

void FWcwSnapJumpCityTestModule::StartupModule()
{
	UE_LOG(LogWcwCityTest, Log, TEXT("WcwSnapJumpCityTest module started. Select UWcwCitySampleOverrideHandler in Project Settings -> Wcw Snap Jump -> CustomJumpHandlerClass."));
}

void FWcwSnapJumpCityTestModule::ShutdownModule()
{
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FWcwSnapJumpCityTestModule, WcwSnapJumpCityTest)
