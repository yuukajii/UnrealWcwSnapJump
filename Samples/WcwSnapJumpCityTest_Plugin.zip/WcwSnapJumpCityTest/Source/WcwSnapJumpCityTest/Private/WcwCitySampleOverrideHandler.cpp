// Copyright (c) 2026 WinterCrownWORKS. All Rights Reserved.
// Licensed under the MIT License.

#include "WcwCitySampleOverrideHandler.h"
#include "WcwSnapJumpCityTestModule.h"
#include "WcwSnapJumpLibrary.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "Engine/GameInstance.h"
#include "Engine/DirectionalLight.h"
#include "Engine/SkyLight.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/SkyLightComponent.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Camera/PlayerCameraManager.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"
#include "HAL/IConsoleManager.h"
#include "HAL/PlatformTime.h"
#include "JsonObjectConverter.h"
#include "Misc/QualifiedFrameTime.h"
#include "TimerManager.h"
#include "WorldPartition/WorldPartitionSubsystem.h"
#include "LevelSequenceActor.h"
#include "LevelSequencePlayer.h"
#include "LevelSequence.h"
#include "MovieSceneSequencePlayer.h"

namespace WcwCityTestInternal
{
	static FString GSimulatedCityEventStep = TEXT("CityFreeRoam_Default");

	static TAutoConsoleVariable<int32> CVarCityTestOverrideGpu(
		TEXT("r.Wcw.CityTest.OverrideGpuStats"),
		1,
		TEXT("1: Replace generic GPU passes with CitySample Nanite/Lumen/VSM/Mass breakdown in UWcwCitySampleOverrideHandler."),
		ECVF_Default);

	static TAutoConsoleVariable<int32> CVarCityTestRestoreCVars(
		TEXT("r.Wcw.CityTest.RestoreCVars"),
		1,
		TEXT("1: Restore captured rendering/scalability CVars from CustomJsonPayload on jump."),
		ECVF_Default);

	static TAutoConsoleVariable<int32> CVarCityTestWaitWP(
		TEXT("r.Wcw.CityTest.WaitWorldPartition"),
		1,
		TEXT("1: Fade camera and wait for UWorldPartitionSubsystem::IsStreamingCompleted() on map load / long jumps."),
		ECVF_Default);

	static TAutoConsoleVariable<int32> CVarCityTestForceReloadMap(
		TEXT("r.Wcw.CityTest.ForceReloadMap"),
		0,
		TEXT("1: Force ShouldTransitionLevel=true even within the same map to test full OpenLevel + NotifyWcwLevelLoadCompleted flow."),
		ECVF_Default);

	static UDirectionalLightComponent* FindAtmosphereSunComponent(UWorld* World)
	{
		if (!World)
		{
			return nullptr;
		}

		UDirectionalLightComponent* FallbackComp = nullptr;
		for (TActorIterator<ADirectionalLight> It(World); It; ++It)
		{
			ADirectionalLight* LightActor = *It;
			if (!LightActor)
			{
				continue;
			}
			UDirectionalLightComponent* DirComp = Cast<UDirectionalLightComponent>(LightActor->GetLightComponent());
			if (!DirComp)
			{
				continue;
			}
			if (DirComp->IsUsedAsAtmosphereSunLight())
			{
				return DirComp;
			}
			if (!FallbackComp)
			{
				FallbackComp = DirComp;
			}
		}
		return FallbackComp;
	}

	static bool ApplySunRotation(UWorld* World, float Pitch, float Yaw)
	{
		UDirectionalLightComponent* SunComp = FindAtmosphereSunComponent(World);
		if (!SunComp)
		{
			return false;
		}

		if (SunComp->Mobility != EComponentMobility::Movable)
		{
			SunComp->SetMobility(EComponentMobility::Movable);
		}

		const FRotator CurrentRot = SunComp->GetComponentRotation();
		SunComp->SetWorldRotation(FRotator(Pitch, Yaw, CurrentRot.Roll));

		for (TActorIterator<ASkyLight> It(World); It; ++It)
		{
			if (ASkyLight* Sky = *It)
			{
				if (USkyLightComponent* SkyComp = Sky->GetLightComponent())
				{
					if (!SkyComp->bRealTimeCapture)
					{
						SkyComp->RecaptureSky();
					}
				}
			}
		}
		return true;
	}

	static int32 GetCVarIntSafe(const TCHAR* Name, int32 DefaultVal)
	{
		if (IConsoleVariable* CVar = IConsoleManager::Get().FindConsoleVariable(Name))
		{
			return CVar->GetInt();
		}
		return DefaultVal;
	}

	static void SetCVarIntSafe(const TCHAR* Name, int32 Val)
	{
		if (IConsoleVariable* CVar = IConsoleManager::Get().FindConsoleVariable(Name))
		{
			if (CVar->GetInt() != Val)
			{
				CVar->Set(Val, ECVF_SetByConsole);
			}
		}
	}

	// Helper command: Wcw.CityTest.SetSun <Pitch> [Yaw]  (e.g. Wcw.CityTest.SetSun -6 215 for sunset, -58 120 for noon)
	static FAutoConsoleCommandWithWorldAndArgs GCmdSetSun(
		TEXT("Wcw.CityTest.SetSun"),
		TEXT("Test helper: Set CitySample Sun DirectionalLight Pitch [and Yaw], e.g. 'Wcw.CityTest.SetSun -6 215'"),
		FConsoleCommandWithWorldAndArgsDelegate::CreateLambda([](const TArray<FString>& Args, UWorld* World)
		{
			if (Args.Num() < 1 || !World)
			{
				UE_LOG(LogWcwCityTest, Warning, TEXT("Usage: Wcw.CityTest.SetSun <Pitch> [Yaw]  (e.g. -6 215 for Sunset, -58 120 for Noon)"));
				return;
			}
			const float NewPitch = FCString::Atof(*Args[0]);
			float NewYaw = 150.0f;
			if (UDirectionalLightComponent* ExistingSun = FindAtmosphereSunComponent(World))
			{
				NewYaw = ExistingSun->GetComponentRotation().Yaw;
			}
			if (Args.Num() >= 2)
			{
				NewYaw = FCString::Atof(*Args[1]);
			}

			if (ApplySunRotation(World, NewPitch, NewYaw) && GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Yellow,
					FString::Printf(TEXT("[WcwCityTest] Sun Updated -> Pitch=%.1f, Yaw=%.1f"), NewPitch, NewYaw));
			}
		}));

	// Helper command: Wcw.CityTest.SetEvent <StepName>  (e.g. Wcw.CityTest.SetEvent Ch02_HighwayChase)
	static FAutoConsoleCommandWithWorldAndArgs GCmdSetEvent(
		TEXT("Wcw.CityTest.SetEvent"),
		TEXT("Test helper: Set simulated title EventStep tag recorded into subsequent WcwSnapJump shots."),
		FConsoleCommandWithWorldAndArgsDelegate::CreateLambda([](const TArray<FString>& Args, UWorld* World)
		{
			if (Args.Num() < 1)
			{
				UE_LOG(LogWcwCityTest, Warning, TEXT("Usage: Wcw.CityTest.SetEvent <EventStepName>"));
				return;
			}
			GSimulatedCityEventStep = Args[0];
			if (World)
			{
				UWcwSnapJumpLibrary::SetWcwCustomTitleTag(World, TEXT("EventStep"), GSimulatedCityEventStep);
			}
			if (GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Cyan,
					FString::Printf(TEXT("[WcwCityTest] Simulated EventStep set to '%s'"), *GSimulatedCityEventStep));
			}
		}));
}

UWcwCitySampleOverrideHandler::UWcwCitySampleOverrideHandler()
{
	// Disable immediate PostLoadMap teleport so we can wait for World Partition cells to stream at the target location first!
	bAutoApplyOnEnginePostLoadMap = false;
}

void UWcwCitySampleOverrideHandler::BeginDestroy()
{
	if (PostLoadMapHandle.IsValid())
	{
		FCoreUObjectDelegates::PostLoadMapWithWorld.Remove(PostLoadMapHandle);
		PostLoadMapHandle.Reset();
	}
	Super::BeginDestroy();
}

void UWcwCitySampleOverrideHandler::GatherStatAndGpuTelemetry_Implementation(
	UObject* WorldContextObject,
	FWcwStatSnapshot& OutStats,
	FWcwMemorySnapshot& OutMemory,
	TArray<FWcwGpuPassEntry>& OutGpuPasses)
{
	Super::GatherStatAndGpuTelemetry_Implementation(WorldContextObject, OutStats, OutMemory, OutGpuPasses);

	if (WcwCityTestInternal::CVarCityTestOverrideGpu.GetValueOnGameThread() == 0)
	{
		return;
	}

	// Replace generic pass list with CitySample-oriented GPU pass telemetry to verify GatherStatAndGpuTelemetry override
	OutGpuPasses.Reset();
	const float TotalGpu = FMath::Max(OutStats.GpuTimeMs, 0.01f);
	const bool bVsmEnabled = WcwCityTestInternal::GetCVarIntSafe(TEXT("r.Shadow.Virtual.Enable"), 1) != 0;

	auto AddCityPass = [&OutGpuPasses, TotalGpu](const TCHAR* PassName, float Share)
	{
		FWcwGpuPassEntry Entry;
		Entry.PassName = PassName;
		Entry.DurationMs = TotalGpu * Share;
		Entry.PercentageOfFrame = Share * 100.0f;
		OutGpuPasses.Add(Entry);
	};

	AddCityPass(TEXT("CitySample::Lumen::ScreenProbeGather & Reflections"), 0.29f);
	AddCityPass(TEXT("CitySample::Nanite::VisBuffer & Raster"), 0.24f);
	AddCityPass(bVsmEnabled ? TEXT("CitySample::VirtualShadowMaps (VSM)") : TEXT("CitySample::CascadedShadowMaps (CSM)"), bVsmEnabled ? 0.20f : 0.12f);
	AddCityPass(TEXT("CitySample::MassCrowd & MassTraffic Skinning"), 0.14f);
	AddCityPass(TEXT("CitySample::TSR & PostProcessing"), bVsmEnabled ? 0.13f : 0.21f);

	OutGpuPasses.Sort([](const FWcwGpuPassEntry& A, const FWcwGpuPassEntry& B)
	{
		return A.DurationMs > B.DurationMs;
	});
}

void UWcwCitySampleOverrideHandler::OnGatherTitleCustomMeta_Implementation(
	UObject* WorldContextObject,
	FWcwSnapJumpData& InOutSnapData)
{
	UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
	if (!World && WorldContextObject)
	{
		World = WorldContextObject->GetWorld();
	}

	InOutSnapData.CustomTitleTags.Add(TEXT("OverrideHandler"), TEXT("WcwCitySampleOverrideHandler"));
	InOutSnapData.CustomTitleTags.Add(TEXT("EventStep"), WcwCityTestInternal::GSimulatedCityEventStep);

	if (World)
	{
		// 1. Capture Player Pawn class & CitySample Traversal Mode (Walking vs [X] Fly vs Vehicle/Drone)
		if (APlayerController* PC = World->GetFirstPlayerController())
		{
			if (APawn* Pawn = PC->GetPawn())
			{
				InOutSnapData.CustomTitleTags.Add(TEXT("PawnClass"), Pawn->GetClass()->GetName());
				if (ACharacter* Char = Cast<ACharacter>(Pawn))
				{
					if (UCharacterMovementComponent* MoveComp = Char->GetCharacterMovement())
					{
						FString ModeStr = TEXT("Walking");
						if (MoveComp->MovementMode == MOVE_Flying)
						{
							ModeStr = TEXT("Flying");
						}
						else if (MoveComp->MovementMode == MOVE_Falling)
						{
							ModeStr = TEXT("Falling");
						}
						InOutSnapData.CustomTitleTags.Add(TEXT("TraversalMode"), ModeStr);
					}
				}
				else
				{
					InOutSnapData.CustomTitleTags.Add(TEXT("TraversalMode"), TEXT("VehicleOrDronePawn"));
				}
			}
		}

		// 2. Capture Sun DirectionalLight Pitch & Yaw (Time-of-Day lighting)
		if (UDirectionalLightComponent* SunComp = WcwCityTestInternal::FindAtmosphereSunComponent(World))
		{
			const FRotator SunRot = SunComp->GetComponentRotation();
			InOutSnapData.CustomTitleTags.Add(TEXT("SunPitch"), FString::Printf(TEXT("%.2f"), SunRot.Pitch));
			InOutSnapData.CustomTitleTags.Add(TEXT("SunYaw"), FString::Printf(TEXT("%.2f"), SunRot.Yaw));
		}

		// 3. Auto-detect any actively playing LevelSequence in the world and record its playback timestamp
		for (TActorIterator<ALevelSequenceActor> It(World); It; ++It)
		{
			ALevelSequenceActor* SeqActor = *It;
			if (!SeqActor)
			{
				continue;
			}
			ULevelSequencePlayer* SeqPlayer = SeqActor->GetSequencePlayer();
			if (SeqPlayer && SeqPlayer->IsPlaying())
			{
				const double CurrentSec = SeqPlayer->GetCurrentTime().AsSeconds();
				InOutSnapData.CustomTitleTags.Add(TEXT("CutsceneActorPath"), SeqActor->GetPathName());
				InOutSnapData.CustomTitleTags.Add(TEXT("CutsceneTimeSec"), FString::Printf(TEXT("%.2f"), CurrentSec));
				break;
			}
		}
	}

	// 4. Serialize custom USTRUCT (FWcwCitySampleRenderState) into CustomJsonPayload
	FWcwCitySampleRenderState RenderState;
	RenderState.VirtualShadowMaps = WcwCityTestInternal::GetCVarIntSafe(TEXT("r.Shadow.Virtual.Enable"), 1);
	RenderState.ReflectionQuality = WcwCityTestInternal::GetCVarIntSafe(TEXT("sg.ReflectionQuality"), 3);
	RenderState.ShadowQuality = WcwCityTestInternal::GetCVarIntSafe(TEXT("sg.ShadowQuality"), 3);
	RenderState.AntiAliasingQuality = WcwCityTestInternal::GetCVarIntSafe(TEXT("sg.AntiAliasingQuality"), 3);
	RenderState.LumenReflections = WcwCityTestInternal::GetCVarIntSafe(TEXT("r.Lumen.Reflections.Allow"), 1);

	FJsonObjectConverter::UStructToJsonObjectString(RenderState, InOutSnapData.CustomJsonPayload, 0, 0, 0, nullptr, false);
}

FString UWcwCitySampleOverrideHandler::FormatThumbnailSummary_Implementation(const FWcwSnapJumpData& SnapData)
{
	FString TraversalMode = TEXT("Standard");
	FString EventStep = TEXT("N/A");
	FString SunPitch = TEXT("N/A");
	UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("TraversalMode"), TraversalMode);
	UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("EventStep"), EventStep);
	UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("SunPitch"), SunPitch);

	TArray<FString> Lines;
	Lines.Add(FString::Printf(TEXT("[CityOverride] %s (%s | Mode: %s)"),
		*SnapData.CaptureTag, *SnapData.LevelName, *TraversalMode));
	Lines.Add(FString::Printf(TEXT("Event: %s | SunPitch: %s deg"),
		*EventStep, *SunPitch));
	Lines.Add(FString::Printf(TEXT("Pos: (%.0f, %.0f, %.0f) | %.1f FPS (GPU %.2fms)"),
		SnapData.CharacterLocation.X, SnapData.CharacterLocation.Y, SnapData.CharacterLocation.Z,
		SnapData.Stats.FPS, SnapData.Stats.GpuTimeMs));

	return FString::Join(Lines, LINE_TERMINATOR);
}

FString UWcwCitySampleOverrideHandler::FormatDetailedReport_Implementation(const FWcwSnapJumpData& SnapData)
{
	TArray<FString> HeaderLines;
	HeaderLines.Add(TEXT("=== [CitySample Title Override Active] ==="));

	FString TraversalMode, PawnClass, EventStep, SunPitch, SunYaw, CutscenePath, CutsceneSec;
	if (UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("TraversalMode"), TraversalMode))
	{
		UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("PawnClass"), PawnClass);
		HeaderLines.Add(FString::Printf(TEXT("  Traversal / Pawn : %s (%s)"), *TraversalMode, *PawnClass));
	}
	if (UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("EventStep"), EventStep))
	{
		HeaderLines.Add(FString::Printf(TEXT("  Simulated Event  : %s"), *EventStep));
	}
	if (UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("SunPitch"), SunPitch))
	{
		UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("SunYaw"), SunYaw);
		HeaderLines.Add(FString::Printf(TEXT("  Sun Angle (ToD)  : Pitch=%s deg, Yaw=%s deg"), *SunPitch, *SunYaw));
	}
	if (UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("CutsceneActorPath"), CutscenePath))
	{
		UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("CutsceneTimeSec"), CutsceneSec);
		HeaderLines.Add(FString::Printf(TEXT("  Active Cutscene  : %s @ %s sec"), *CutscenePath, *CutsceneSec));
	}

	if (!SnapData.CustomJsonPayload.IsEmpty())
	{
		FWcwCitySampleRenderState DecodedState;
		if (FJsonObjectConverter::JsonObjectStringToUStruct(SnapData.CustomJsonPayload, &DecodedState, 0, 0))
		{
			HeaderLines.Add(FString::Printf(
				TEXT("  Render Preset    : VSM=%d | LumenRefl=%d | sg.Refl=%d | sg.Shadow=%d | sg.AA=%d"),
				DecodedState.VirtualShadowMaps,
				DecodedState.LumenReflections,
				DecodedState.ReflectionQuality,
				DecodedState.ShadowQuality,
				DecodedState.AntiAliasingQuality));
		}
	}
	HeaderLines.Add(TEXT(""));

	const FString BaseReport = Super::FormatDetailedReport_Implementation(SnapData);
	return FString::Join(HeaderLines, LINE_TERMINATOR) + LINE_TERMINATOR + BaseReport;
}

bool UWcwCitySampleOverrideHandler::ShouldTransitionLevel_Implementation(UWorld* World, const FWcwSnapJumpData& SnapData)
{
	if (Super::ShouldTransitionLevel_Implementation(World, SnapData))
	{
		return true;
	}

	if (WcwCityTestInternal::CVarCityTestForceReloadMap.GetValueOnGameThread() != 0)
	{
		UE_LOG(LogWcwCityTest, Log, TEXT("[CityOverride] r.Wcw.CityTest.ForceReloadMap=1 -> Forcing map transition to test async load pipeline."));
		return true;
	}

	return false;
}

bool UWcwCitySampleOverrideHandler::HandleLevelTransition_Implementation(UWorld* World, const FWcwSnapJumpData& SnapData)
{
	if (!World)
	{
		return false;
	}

	CleanupAsyncState(World);
	PendingStreamTargetLocation = SnapData.CharacterLocation;

	if (APlayerController* PC = World->GetFirstPlayerController())
	{
		if (PC->PlayerCameraManager)
		{
			PC->PlayerCameraManager->StartCameraFade(0.0f, 1.0f, 0.2f, FLinearColor::Black, false, true);
		}
	}

	PostLoadMapHandle = FCoreUObjectDelegates::PostLoadMapWithWorld.AddUObject(
		this, &UWcwCitySampleOverrideHandler::OnTargetMapLoaded);

	return Super::HandleLevelTransition_Implementation(World, SnapData);
}

void UWcwCitySampleOverrideHandler::OnTargetMapLoaded(UWorld* LoadedWorld)
{
	if (PostLoadMapHandle.IsValid())
	{
		FCoreUObjectDelegates::PostLoadMapWithWorld.Remove(PostLoadMapHandle);
		PostLoadMapHandle.Reset();
	}

	if (!LoadedWorld)
	{
		return;
	}

	if (WcwCityTestInternal::CVarCityTestWaitWP.GetValueOnGameThread() == 0)
	{
		UWcwSnapJumpLibrary::NotifyWcwLevelLoadCompleted(LoadedWorld);
		return;
	}

	// Keep screen black and place Pawn at target location in MOVE_Flying so World Partition streams destination cells!
	if (APlayerController* PC = LoadedWorld->GetFirstPlayerController())
	{
		if (PC->PlayerCameraManager)
		{
			PC->PlayerCameraManager->StartCameraFade(1.0f, 1.0f, 0.05f, FLinearColor::Black, false, true);
		}
		if (APawn* Pawn = PC->GetPawn())
		{
			if (ACharacter* Char = Cast<ACharacter>(Pawn))
			{
				if (UCharacterMovementComponent* MoveComp = Char->GetCharacterMovement())
				{
					MoveComp->StopMovementImmediately();
					MoveComp->SetMovementMode(MOVE_Flying);
				}
			}
			Pawn->SetActorLocation(PendingStreamTargetLocation, false, nullptr, ETeleportType::TeleportPhysics);
		}
	}

	AsyncWaitStartTimeSec = FPlatformTime::Seconds();
	TWeakObjectPtr<UWorld> WeakWorld(LoadedWorld);
	LoadedWorld->GetTimerManager().SetTimer(
		StreamingPollTimerHandle,
		FTimerDelegate::CreateUObject(this, &UWcwCitySampleOverrideHandler::PollWorldPartitionStreaming, WeakWorld, true),
		0.15f,
		true);
}

void UWcwCitySampleOverrideHandler::PollWorldPartitionStreaming(TWeakObjectPtr<UWorld> WeakWorld, bool bNotifySubsystemOnComplete)
{
	UWorld* World = WeakWorld.Get();
	if (!World)
	{
		return;
	}

	bool bReady = true;
	if (UWorldPartitionSubsystem* WPSubsystem = World->GetSubsystem<UWorldPartitionSubsystem>())
	{
		bReady = WPSubsystem->IsStreamingCompleted();
	}

	const double ElapsedSec = FPlatformTime::Seconds() - AsyncWaitStartTimeSec;
	if (!bReady && ElapsedSec < 8.0)
	{
		return;
	}

	World->GetTimerManager().ClearTimer(StreamingPollTimerHandle);

	UE_LOG(LogWcwCityTest, Log, TEXT("[CityOverride] World Partition streaming ready after %.2fs. Completing jump."), ElapsedSec);

	if (bNotifySubsystemOnComplete)
	{
		// Triggers UWcwSnapJumpSubsystem::ApplyPendingPostLoadJump -> HandleSameLevelTeleport + HandlePostJumpSetup!
		UWcwSnapJumpLibrary::NotifyWcwLevelLoadCompleted(World);
	}

	if (APlayerController* PC = World->GetFirstPlayerController())
	{
		if (PC->PlayerCameraManager)
		{
			PC->PlayerCameraManager->StartCameraFade(1.0f, 0.0f, 0.5f, FLinearColor::Black, false, false);
		}
	}
}

bool UWcwCitySampleOverrideHandler::HandleSameLevelTeleport_Implementation(UWorld* World, const FWcwSnapJumpData& SnapData)
{
	if (!World)
	{
		return false;
	}

	APlayerController* PC = World->GetFirstPlayerController();
	if (!PC)
	{
		return false;
	}

	float JumpDistance = 0.0f;
	if (APawn* Pawn = PC->GetPawn())
	{
		JumpDistance = FVector::Dist(Pawn->GetActorLocation(), SnapData.CharacterLocation);

		if (ACharacter* Char = Cast<ACharacter>(Pawn))
		{
			if (UCharacterMovementComponent* MoveComp = Char->GetCharacterMovement())
			{
				MoveComp->StopMovementImmediately();

				FString SavedMode;
				if (UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("TraversalMode"), SavedMode))
				{
					if (SavedMode.Equals(TEXT("Flying"), ESearchCase::IgnoreCase))
					{
						MoveComp->SetMovementMode(MOVE_Flying);
					}
					else if (MoveComp->MovementMode == MOVE_Flying)
					{
						MoveComp->SetMovementMode(MOVE_Walking);
					}
				}
			}
		}
	}

	const bool bTeleported = Super::HandleSameLevelTeleport_Implementation(World, SnapData);

	// Smooth camera fade-in on long-distance (>500m) same-level warps across Big_City_LVL
	if (bTeleported && JumpDistance > 50000.0f && WcwCityTestInternal::CVarCityTestWaitWP.GetValueOnGameThread() != 0)
	{
		if (PC->PlayerCameraManager)
		{
			PC->PlayerCameraManager->StartCameraFade(1.0f, 0.0f, 0.45f, FLinearColor::Black, false, false);
		}
	}

	return bTeleported;
}

void UWcwCitySampleOverrideHandler::HandlePostJumpSetup_Implementation(UWorld* World, const FWcwSnapJumpData& SnapData)
{
	if (!World)
	{
		return;
	}

	// 1. Restore simulated EventStep
	FString RestoredEvent = TEXT("N/A");
	if (UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("EventStep"), RestoredEvent) && !RestoredEvent.IsEmpty())
	{
		WcwCityTestInternal::GSimulatedCityEventStep = RestoredEvent;
		UWcwSnapJumpLibrary::SetWcwCustomTitleTag(World, TEXT("EventStep"), RestoredEvent);
	}

	// 2. Restore Sun DirectionalLight Pitch & Yaw (Time-of-Day lighting)
	FString SunPitchStr, SunYawStr;
	bool bRestoredSun = false;
	if (UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("SunPitch"), SunPitchStr) &&
		UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("SunYaw"), SunYawStr))
	{
		bRestoredSun = WcwCityTestInternal::ApplySunRotation(
			World,
			FCString::Atof(*SunPitchStr),
			FCString::Atof(*SunYawStr));
	}

	// 3. Restore rendering CVars from CustomJsonPayload USTRUCT
	bool bRestoredCVars = false;
	FWcwCitySampleRenderState RestoredRenderState;
	if (WcwCityTestInternal::CVarCityTestRestoreCVars.GetValueOnGameThread() != 0 &&
		!SnapData.CustomJsonPayload.IsEmpty())
	{
		if (FJsonObjectConverter::JsonObjectStringToUStruct(SnapData.CustomJsonPayload, &RestoredRenderState, 0, 0))
		{
			WcwCityTestInternal::SetCVarIntSafe(TEXT("r.Shadow.Virtual.Enable"), RestoredRenderState.VirtualShadowMaps);
			WcwCityTestInternal::SetCVarIntSafe(TEXT("sg.ReflectionQuality"), RestoredRenderState.ReflectionQuality);
			WcwCityTestInternal::SetCVarIntSafe(TEXT("sg.ShadowQuality"), RestoredRenderState.ShadowQuality);
			WcwCityTestInternal::SetCVarIntSafe(TEXT("sg.AntiAliasingQuality"), RestoredRenderState.AntiAliasingQuality);
			WcwCityTestInternal::SetCVarIntSafe(TEXT("r.Lumen.Reflections.Allow"), RestoredRenderState.LumenReflections);
			bRestoredCVars = true;
		}
	}

	// 4. Restore LevelSequence playback position if a cutscene was active during capture
	FString CutscenePath, CutsceneSecStr;
	if (UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("CutsceneActorPath"), CutscenePath) && !CutscenePath.IsEmpty())
	{
		const float StartSec = UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("CutsceneTimeSec"), CutsceneSecStr)
			? FCString::Atof(*CutsceneSecStr)
			: 0.0f;

		for (TActorIterator<ALevelSequenceActor> It(World); It; ++It)
		{
			ALevelSequenceActor* SeqActor = *It;
			if (SeqActor && SeqActor->GetPathName().Equals(CutscenePath, ESearchCase::IgnoreCase))
			{
				if (ULevelSequencePlayer* SeqPlayer = SeqActor->GetSequencePlayer())
				{
					SeqPlayer->SetPlaybackPosition(FMovieSceneSequencePlaybackParams(StartSec, EUpdatePositionMethod::Play));
					SeqPlayer->Play();
				}
				break;
			}
		}
	}

	// 5. On-screen visual confirmation banner for verification
	FString TraversalMode = TEXT("Standard");
	UWcwSnapJumpLibrary::GetWcwCustomTitleTag(SnapData, TEXT("TraversalMode"), TraversalMode);

	const FString SummaryMsg = FString::Printf(
		TEXT("[WcwCityTest Override Applied] Tag=%s | Mode=%s | Event=%s | Sun=%s | CVars=%s"),
		*SnapData.CaptureTag,
		*TraversalMode,
		*RestoredEvent,
		bRestoredSun ? *FString::Printf(TEXT("P:%s/Y:%s"), *SunPitchStr, *SunYawStr) : TEXT("Unchanged"),
		bRestoredCVars ? *FString::Printf(TEXT("VSM:%d,Refl:%d"), RestoredRenderState.VirtualShadowMaps, RestoredRenderState.ReflectionQuality) : TEXT("Skipped"));

	UE_LOG(LogWcwCityTest, Log, TEXT("%s"), *SummaryMsg);
	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 6.5f, FColor::Cyan, SummaryMsg);
	}
}

void UWcwCitySampleOverrideHandler::CleanupAsyncState(UWorld* World)
{
	if (PostLoadMapHandle.IsValid())
	{
		FCoreUObjectDelegates::PostLoadMapWithWorld.Remove(PostLoadMapHandle);
		PostLoadMapHandle.Reset();
	}
	if (World)
	{
		World->GetTimerManager().ClearTimer(StreamingPollTimerHandle);
	}
}
