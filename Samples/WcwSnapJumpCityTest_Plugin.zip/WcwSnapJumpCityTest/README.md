# WcwSnapJumpCityTest — Title Override Tutorial & Sample Plugin (For UE 5.8 CitySample)

**Language / 言語**: **English | 日本語**

## English

> **Target Sample Project**: **Epic Games "CitySample" (Unreal Engine 5.8)**
> *(Note: Implemented purely with standard Unreal Engine APIs—no hard dependency on `CitySample` C++ modules—so you can also drop it into other World Partition / Character projects or copy its C++ patterns directly into your own title.)*

`WcwSnapJumpCityTest` is an official tutorial and verification plugin demonstrating how to subclass `UWcwSnapJumpHandler` (`UWcwCitySampleOverrideHandler`) in **UE 5.8 CitySample** without modifying `CitySample` source files.

### What This Sample Demonstrates in CitySample
1. **Custom GPU Pass Telemetry (`GatherStatAndGpuTelemetry`)**: Replaces generic pass names with `CitySample::Lumen`, `Nanite`, `VSM`, and `MassCrowd` pass entries.
2. **Custom Title State & `USTRUCT` JSON (`OnGatherTitleCustomMeta`)**: Records Character traversal mode (`Walking` vs CitySample `[X] Fly` mode), Sun `ADirectionalLight` Pitch/Yaw, simulated `EventStep`, active `ALevelSequenceActor` playback timestamp, and scalability CVars (`FWcwCitySampleRenderState` serialized into `CustomJsonPayload`).
3. **Custom UI Formatting (`FormatThumbnailSummary` & `FormatDetailedReport`)**: Displays `[CityOverride]` badges and decoded render presets in both `Wcw SnapJump Viewer` (Editor) and the runtime overlay menu.
4. **World Partition Streaming Wait & State Restoration (`HandleLevelTransition`, `HandleSameLevelTeleport`, `HandlePostJumpSetup`)**: Waits for `UWorldPartitionSubsystem::IsStreamingCompleted()` with a camera fade, restores `MOVE_Flying` / `MOVE_Walking` without falling, restores Sun angle & CVars, and scrubs active cutscenes.

### How to Use in CitySample (UE 5.8)
1. Extract `WcwSnapJumpCityTest` into `CitySample/Plugins/WcwSnapJumpCityTest/` alongside `CitySample/Plugins/WcwSnapJump/` and build `CitySample`.
2. Open **`Project Settings -> Extension -> Wcw Snap Jump -> CustomJumpHandlerClass`** and select **`Wcw CitySample Override Test Handler`**.
3. Open `Big_City_LVL` (or `Small_City_LVL`), start PIE (or a Packaged build), and test using these console commands:

```text
Wcw.CityTest.SetSun -58 120
Wcw.CityTest.SetEvent Ch01_DowntownNoon
Wcw.SnapJump.Shot Test_Noon_Walk

Wcw.CityTest.SetSun -6 215
Wcw.CityTest.SetEvent Ch02_SunsetRoofFly
r.Shadow.Virtual.Enable 0
Wcw.SnapJump.Shot Test_Sunset_Fly
```

* Tip: Press `X` in `CitySample` before capturing `Test_Sunset_Fly` to fly high above Downtown; jumping between the two snapshots will automatically toggle `Flying` vs `Walking`, noon vs sunset lighting, and VSM state.
* Optional CVars: `r.Wcw.CityTest.OverrideGpuStats` (`1`), `r.Wcw.CityTest.RestoreCVars` (`1`), `r.Wcw.CityTest.WaitWorldPartition` (`1`), `r.Wcw.CityTest.ForceReloadMap` (`0` -> `1` to test full `OpenLevel` + `NotifyWcwLevelLoadCompleted` reload).

## 日本語

> **対象サンプルプロジェクト**: **Epic Games 配布『CitySample』（Unreal Engine 5.8）**
> *(※内部実装はエンジン標準C++ APIのみで記述されており `CitySample` 固有モジュールへのビルド依存はないため、他の World Partition / Character プロジェクトでの動作や、自社タイトル用ハンドラ実装の雛形としてもそのまま流用できます。)*

`WcwSnapJumpCityTest` は、Epic Games の **UE 5.8『CitySample』** をベースに、プロジェクト本体のC++コードを一切変更せず `UWcwSnapJumpHandler` 派生クラス（`UWcwCitySampleOverrideHandler`）の全Override機能を体験・検証できる公式チュートリアル／サンプルプラグインです。

### CitySample 上で確認できる Override 機能
1. **独自GPUプロファイラ項目の注入 (`GatherStatAndGpuTelemetry`)**: 標準パス名を `CitySample::Lumen` / `Nanite` / `VSM` / `MassCrowd` 等の項目へ差し替え。
2. **タイトル固有状態＆独自 `USTRUCT` の記録 (`OnGatherTitleCustomMeta`)**: `CitySample` の地上徒歩／`[X] Fly` 空中飛行モード、太陽ライト角度（時間帯）、擬似イベント進捗ID、再生中 `ALevelSequenceActor` の秒数、描画CVar構造体（`FWcwCitySampleRenderState` の `CustomJsonPayload` 格納）を記録。
3. **Editor / Runtime 共通のUI表示カスタム (`FormatThumbnailSummary` / `FormatDetailedReport`)**: サムネイル横や詳細レポートに `[CityOverride]` バッジ・飛行状態・太陽角度・描画プリセットを表示。
4. **World Partition 完了待ち＆状態復元 (`HandleLevelTransition` / `HandleSameLevelTeleport` / `HandlePostJumpSetup`)**: ジャンプ時に `UWorldPartitionSubsystem::IsStreamingCompleted()` をカメラフェード付きで待機し、上空飛行状態の維持（落下防止）・太陽ライティング・描画CVar・カットシーン再生位置を自動復元。

### CitySample（UE 5.8）での導入・テスト手順
1. 本フォルダ `WcwSnapJumpCityTest` を `CitySample/Plugins/WcwSnapJumpCityTest/`（`Plugins/WcwSnapJump/` の隣）に配置してビルドします。
2. **`Project Settings -> Extension -> Wcw Snap Jump -> CustomJumpHandlerClass`** で **`Wcw CitySample Override Test Handler`** を選択します。
3. `Big_City_LVL`（または `Small_City_LVL`）をPIEまたはパッケージで起動し、上記コンソールコマンド（2枚目は `X` キーで上空飛行中にして撮影）を実行して交互にジャンプすると、全状態の自動切り替わりを確認できます。

License: MIT License — Copyright (c) 2026 WinterCrownWORKS
