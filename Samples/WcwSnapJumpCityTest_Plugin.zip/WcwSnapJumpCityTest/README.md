# WcwSnapJumpCityTest — Title Override Tutorial & Sample Plugin (For UE 5.8 CitySample)

**Language / 言語**: **English | 日本語** | **Version**: `0.2.0`

## English

> **Target Sample Project**: **Epic Games "CitySample" (Unreal Engine 5.8)**
> *(Note: Implemented purely with standard Unreal Engine APIs—no hard dependency on `CitySample` C++ modules—so you can also drop it into other World Partition / Character projects or copy its C++ patterns directly into your own title.)*

`WcwSnapJumpCityTest` is an official tutorial and verification plugin demonstrating how to subclass `UWcwSnapJumpHandler` (`UWcwCitySampleOverrideHandler`) in **UE 5.8 CitySample** without modifying `CitySample` or `WcwSnapJump` source files.

### What This Sample Demonstrates in CitySample
1. **Custom GPU Pass Telemetry (`GatherStatAndGpuTelemetry`)**: Replaces generic pass names with `CitySample::Lumen`, `Nanite`, `VSM`, and `MassCrowd` pass entries.
2. **Custom Title State & `USTRUCT` JSON (`OnGatherTitleCustomMeta`)**: Records Character traversal mode (`Walking` vs CitySample `[X] Fly` mode), Sun `ADirectionalLight` Pitch/Yaw, simulated `EventStep`, active `ALevelSequenceActor` playback timestamp, and scalability CVars (`FWcwCitySampleRenderState` serialized into `CustomJsonPayload`).
3. **Custom UI Formatting (`FormatThumbnailSummary` & `FormatDetailedReport`)**: Displays `[CityOverride]` badges and decoded render presets in both `Wcw SnapJump Viewer` (Editor) and the runtime overlay menu.
4. **World Partition Streaming Wait & State Restoration (`HandleLevelTransition`, `HandleSameLevelTeleport`, `HandlePostJumpSetup`)**: Waits for `UWorldPartitionSubsystem::IsStreamingCompleted()` with a camera fade, restores `MOVE_Flying` / `MOVE_Walking` without falling, restores Sun angle & CVars, and scrubs active cutscenes.
5. **Interactive Redmine UI Controls & Payload Overrides (`v0.2.0+` — `GatherIssueTrackerUiFields`)**: Automatically adds a **`Title Custom Fields (Handler Override)`** section inside `Wcw SnapJump Viewer` with live interactive controls for **Priority (`priority_id`)** (synced from Redmine `/enumerations/issue_priorities.json`), **`CustomFieldTest`** (editable Text box), and **`CustomFieldTest_List`** (Dropdown / Multi-Select list synced with Redmine `possible_values` and `multiple=true` JSON array formatting), plus `FormatIssueTrackerSubject` and `FormatIssueTrackerTelemetryBlock`.

### How to Use in CitySample (UE 5.8)
1. Extract `WcwSnapJumpCityTest` into `CitySample/Plugins/WcwSnapJumpCityTest/` alongside `CitySample/Plugins/WcwSnapJump/` and build `CitySample`.
2. Open **`Project Settings -> Extension -> Wcw Snap Jump -> CustomJumpHandlerClass`** and select **`Wcw CitySample Override Test Handler`**.
3. Open `Window -> Wcw SnapJump Viewer -> Redmine Ticket Post` to edit **Priority**, **CustomFieldTest**, and **CustomFieldTest_List** directly in the UI and post tickets to Redmine.
4. Open `Big_City_LVL` (or `Small_City_LVL`), start PIE (or a Packaged build), and test scene capture & jump using these console commands:

```text
Wcw.CityTest.SetSun -58 120
Wcw.CityTest.SetEvent Ch01_DowntownNoon
Wcw.SnapJump.Shot Test_Noon_Walk

Wcw.CityTest.SetSun -6 215
Wcw.CityTest.SetEvent Ch02_SunsetRoofFly
r.Shadow.Virtual.Enable 0
Wcw.SnapJump.Shot Test_Sunset_Fly
```

* Optional CVars: `r.Wcw.CityTest.MultiSelectList` (`0` = Dropdown, `1` = Multi-Select Checkboxes for `CustomFieldTest_List`), `r.Wcw.CityTest.OverrideRedmineFields` (`0` -> `1` to enable `[Platform][Mode][Tag]` Redmine subject & category preset demo), `r.Wcw.CityTest.OverrideGpuStats` (`1`), `r.Wcw.CityTest.RestoreCVars` (`1`), `r.Wcw.CityTest.WaitWorldPartition` (`1`), `r.Wcw.CityTest.ForceReloadMap` (`0`).

## 日本語

> **対象サンプルプロジェクト**: **Epic Games 配布『CitySample』（Unreal Engine 5.8）**
> *(※内部実装はエンジン標準C++ APIのみで記述されており `CitySample` 固有モジュールへのビルド依存はないため、他の World Partition / Character プロジェクトでの動作や、自社タイトル用ハンドラ実装の雛形としてもそのまま流用できます。)*

`WcwSnapJumpCityTest` は、Epic Games の **UE 5.8『CitySample』** をベースに、プロジェクト本体やプラグイン本体のC++コードを一切変更せず `UWcwSnapJumpHandler` 派生クラス（`UWcwCitySampleOverrideHandler`）の全Override機能を体験・検証できる公式チュートリアル／サンプルプラグインです。

### CitySample 上で確認できる Override 機能
1. **独自GPUプロファイラ項目の注入 (`GatherStatAndGpuTelemetry`)**: 標準パス名を `CitySample::Lumen` / `Nanite` / `VSM` / `MassCrowd` 等の項目へ差し替え。
2. **タイトル固有状態＆独自 `USTRUCT` の記録 (`OnGatherTitleCustomMeta`)**: `CitySample` の地上徒歩／`[X] Fly` 空中飛行モード、太陽ライト角度（時間帯）、擬似イベント進捗ID、再生中 `ALevelSequenceActor` の秒数、描画CVar構造体（`FWcwCitySampleRenderState` の `CustomJsonPayload` 格納）を記録。
3. **Editor / Runtime 共通のUI表示カスタム (`FormatThumbnailSummary` / `FormatDetailedReport`)**: サムネイル横や詳細レポートに `[CityOverride]` バッジ・飛行状態・太陽角度・描画プリセットを表示。
4. **World Partition 完了待ち＆状態復元 (`HandleLevelTransition` / `HandleSameLevelTeleport` / `HandlePostJumpSetup`)**: ジャンプ時に `UWorldPartitionSubsystem::IsStreamingCompleted()` をカメラフェード付きで待機し、上空飛行状態の維持（落下防止）・太陽ライティング・描画CVar・カットシーン再生位置を自動復元。
5. **Redmine 起票UI＆項目のタイトル側オーバーライド (`v0.2.0+` — `GatherIssueTrackerUiFields`)**: `Wcw SnapJump Viewer` の Redmine タブ内に **`Title Custom Fields (Handler Override)`** 欄を動的追加し、**優先度（`Priority` / `/enumerations/issue_priorities.json` から自動取得）**・**`CustomFieldTest`（テキスト入力）**・**`CustomFieldTest_List`（リスト選択・単一／複数選択 `multiple=true` 両対応、`r.Wcw.CityTest.MultiSelectList 1` で複数チェックボックス表示切替も可能）** をUIから自在に変更して起票できるほか、`FormatIssueTrackerSubject`・`FormatIssueTrackerTelemetryBlock` の拡張例を収録しています。

### CitySample（UE 5.8）での導入・テスト手順
1. 本フォルダ `WcwSnapJumpCityTest` を `CitySample/Plugins/WcwSnapJumpCityTest/`（`Plugins/WcwSnapJump/` の隣）に配置してビルドします。
2. **`Project Settings -> Extension -> Wcw Snap Jump -> CustomJumpHandlerClass`** で **`Wcw CitySample Override Test Handler`** を選択します。
3. `Window -> Wcw SnapJump Viewer` の **`Redmine Ticket Post`** タブを開くと、タイトル専用UI欄から **優先度・CustomFieldTest・CustomFieldTest_List** を操作して Redmine へ起票できます。
4. `Big_City_LVL`（または `Small_City_LVL`）をPIEまたはパッケージで起動し、上記コンソールコマンド（2枚目は `X` キーで上空飛行中にして撮影）を実行して交互にジャンプすると、全状態の自動切り替わりを確認できます。

License: MIT License — Copyright (c) 2026 WinterCrownWORKS
