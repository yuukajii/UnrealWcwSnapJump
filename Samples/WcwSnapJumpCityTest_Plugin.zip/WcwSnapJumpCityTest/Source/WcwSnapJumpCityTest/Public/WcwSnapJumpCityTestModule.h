// Copyright (c) 2026 WinterCrownWORKS. All Rights Reserved.
// Licensed under the MIT License.

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

WCWSNAPJUMPCITYTEST_API DECLARE_LOG_CATEGORY_EXTERN(LogWcwCityTest, Log, All);

class FWcwSnapJumpCityTestModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};
