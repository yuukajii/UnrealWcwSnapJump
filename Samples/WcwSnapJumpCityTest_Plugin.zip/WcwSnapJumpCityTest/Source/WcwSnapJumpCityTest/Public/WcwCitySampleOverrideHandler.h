// Copyright (c) 2026 WinterCrownWORKS. All Rights Reserved.
// Licensed under the MIT License.

#pragma once

#include "CoreMinimal.h"
#include "WcwSnapJumpHandler.h"
#include "Engine/EngineTypes.h"
#include "WcwCitySampleOverrideHandler.generated.h"

/**
 * Custom USTRUCT serialized into FWcwSnapJumpData::CustomJsonPayload to test
 * complex struct round-tripping (Scalability & Rendering CVars in CitySample).
 */
USTRUCT(BlueprintType)
struct WCWSNAPJUMPCITYTEST_API FWcwCitySampleRenderState
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Wcw|CityTest")
	int32 VirtualShadowMaps = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Wcw|CityTest")
	int32 ReflectionQuality = 3;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Wcw|CityTest")
	int32 ShadowQuality = 3;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Wcw|CityTest")
	int32 AntiAliasingQuality = 3;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Wcw|CityTest")
	int32 LumenReflections = 1;
};

/**
 * Drop-in Title Override verification handler for Unreal Engine 5.8 CitySample (v0.2.0).
 *
 * Assign in:
 *   Project Settings -> Extension -> Wcw Snap Jump -> CustomJumpHandlerClass
 *
 * Verifies all 5 Override phases:
 *   1. Custom Stat/GPU pass profiler injection (CitySample Nanite/Lumen/VSM/Mass passes).
 *   2. Custom Title Tags & USTRUCT JSON capture (Fly/Walk mode, Sun angle, EventStep, Cutscene time, Render CVars).
 *   3. Custom Thumbnail & Detailed Report UI formatting in both Editor Viewer and Runtime Menu.
 *   4. Async World Partition streaming wait + Camera Fade + MovementMode/Sun/CVar/Cutscene restoration on Jump.
 *   5. Interactive Redmine UI Controls (Priority dropdown, CustomFieldTest textbox, CustomFieldTest_List dropdown)
 *      & Ticket Payload Overrides (Subject prefix, Telemetry <pre> block, Preset selection, Standard & Custom fields).
 */
UCLASS(Blueprintable, BlueprintType, DisplayName = "Wcw CitySample Override Test Handler")
class WCWSNAPJUMPCITYTEST_API UWcwCitySampleOverrideHandler : public UWcwSnapJumpHandler
{
	GENERATED_BODY()

public:
	UWcwCitySampleOverrideHandler();
	virtual void BeginDestroy() override;

	// [1] Capture Overrides
	virtual void GatherStatAndGpuTelemetry_Implementation(
		UObject* WorldContextObject,
		FWcwStatSnapshot& OutStats,
		FWcwMemorySnapshot& OutMemory,
		TArray<FWcwGpuPassEntry>& OutGpuPasses) override;

	virtual void OnGatherTitleCustomMeta_Implementation(
		UObject* WorldContextObject,
		FWcwSnapJumpData& InOutSnapData) override;

	// [2] UI Formatting Overrides (Editor Viewer & Runtime Overlay)
	virtual FString FormatThumbnailSummary_Implementation(const FWcwSnapJumpData& SnapData) override;
	virtual FString FormatDetailedReport_Implementation(const FWcwSnapJumpData& SnapData) override;

	// [3] Level Transition, World Partition Streaming Wait & Post-Jump State Restoration
	virtual bool ShouldTransitionLevel_Implementation(UWorld* World, const FWcwSnapJumpData& SnapData) override;
	virtual bool HandleLevelTransition_Implementation(UWorld* World, const FWcwSnapJumpData& SnapData) override;
	virtual bool HandleSameLevelTeleport_Implementation(UWorld* World, const FWcwSnapJumpData& SnapData) override;
	virtual void HandlePostJumpSetup_Implementation(UWorld* World, const FWcwSnapJumpData& SnapData) override;

	// [4] Issue Tracker / Redmine UI & Ticket Overrides (v0.2.0+)
	virtual void GatherIssueTrackerUiFields_Implementation(
		const FWcwSnapJumpData& SnapData,
		TArray<FWcwIssueTrackerUiField>& OutUiFields) override;

	virtual FString FormatIssueTrackerSubject_Implementation(
		const FWcwSnapJumpData& SnapData,
		const FString& UserEnteredTitle) override;

	virtual FString FormatIssueTrackerTelemetryBlock_Implementation(
		const FWcwSnapJumpData& SnapData) override;

	virtual void GatherIssueTrackerPresetSelection_Implementation(
		const FWcwSnapJumpData& SnapData,
		FWcwIssueTrackerPresetSelection& OutPresetSelection) override;

	virtual void GatherIssueTrackerIssueFields_Implementation(
		const FWcwSnapJumpData& SnapData,
		TMap<FString, FString>& InOutIssueFields) override;

	virtual void GatherIssueTrackerCustomFields_Implementation(
		const FWcwSnapJumpData& SnapData,
		TMap<FString, FString>& InOutCustomFields) override;

private:
	void OnTargetMapLoaded(UWorld* LoadedWorld);
	void PollWorldPartitionStreaming(TWeakObjectPtr<UWorld> WeakWorld, bool bNotifySubsystemOnComplete);
	void CleanupAsyncState(UWorld* World);

	FDelegateHandle PostLoadMapHandle;
	FTimerHandle StreamingPollTimerHandle;
	FVector PendingStreamTargetLocation = FVector::ZeroVector;
	double AsyncWaitStartTimeSec = 0.0;
};
